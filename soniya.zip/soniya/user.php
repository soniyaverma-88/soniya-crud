<?php
include 'connect.php';
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];
  $password=$_POST['pass'];

  $sql="insert into crud (name,email,mobile,password) 
  values('$name','$email','$mobile','$password')";
  $result=mysqli_query($conn,$sql);
  if($result){
   // echo"data inserted successully";
   header('location:display.php');
  }else{
    die(mysqli_error($conn));
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"> 
</head>
<body>
    <div class="container my-5">
      <form method="POST">
  <div class="form-group">
     <label>name</label>
    <input type="text" class="form-control" placeholder="enter your name" name="name" autoocomplete="off">
  </div>
  <div class="form-group">
  <label>email</label>
    <input type="text" class="form-control" placeholder="enter your email" name="email" autoocomplete="off">
  </div>
  <div class="form-group">
  <label>mobile</label>
    <input type="text" class="form-control" placeholder="enter your mobile" name="mobile" autoocomplete="off">
  </div>
  <div class="form-group">
  <label>password</label>
    <input type="text" class="form-control" placeholder="enter your password" name="pass" autoocomplete="off">
  </div>
  <button type="submit" name="submit" class="btn btn-primary">submit</button>
</form> 
</body>
</html>