<?php

$conn=new mysqli('localhost','root','','soniya');
if(!$conn){
    die(mysqli_error($conn));
}
